package net;


public interface DoodleObserver {
	
	public void sendDoodle(DoodleEvent e);
	
}
