package ui;

public interface ErrorObserver {
	
	public void sendError(String text);

	public void hide();

}
